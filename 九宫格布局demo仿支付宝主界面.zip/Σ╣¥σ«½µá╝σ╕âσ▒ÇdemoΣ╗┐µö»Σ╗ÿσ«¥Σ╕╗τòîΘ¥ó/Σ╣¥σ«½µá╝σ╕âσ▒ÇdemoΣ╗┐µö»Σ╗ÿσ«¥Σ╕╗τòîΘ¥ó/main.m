//
//  main.m
//  九宫格布局demo仿支付宝主界面
//
//  Created by 冯垚杰 on 16/6/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
