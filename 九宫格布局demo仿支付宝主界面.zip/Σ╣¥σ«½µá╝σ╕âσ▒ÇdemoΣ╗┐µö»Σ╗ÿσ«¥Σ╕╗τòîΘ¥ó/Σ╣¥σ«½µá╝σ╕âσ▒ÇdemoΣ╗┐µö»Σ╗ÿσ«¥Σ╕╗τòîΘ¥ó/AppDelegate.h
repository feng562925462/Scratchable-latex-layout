//
//  AppDelegate.h
//  九宫格布局demo仿支付宝主界面
//
//  Created by 冯垚杰 on 16/6/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

