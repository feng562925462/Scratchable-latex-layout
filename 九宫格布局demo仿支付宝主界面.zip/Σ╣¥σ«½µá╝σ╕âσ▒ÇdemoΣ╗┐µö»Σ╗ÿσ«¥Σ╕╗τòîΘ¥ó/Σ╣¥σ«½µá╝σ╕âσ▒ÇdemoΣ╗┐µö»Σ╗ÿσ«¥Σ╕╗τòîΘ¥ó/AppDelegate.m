//
//  AppDelegate.m
//  九宫格布局demo仿支付宝主界面
//
//  Created by 冯垚杰 on 16/6/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import "AppDelegate.h"
#import "HomePageViewController.h"
#import "PTSingletonManager.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    // 导航条的外观设置
    if([UINavigationBar conformsToProtocol:@protocol(UIAppearanceContainer)]) { // 检查是否实现了该协议
        
        [UINavigationBar appearance].tintColor = [UIColor whiteColor];// 改变系统返回按钮的颜色
        [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName : [UIFont boldSystemFontOfSize:18], NSForegroundColorAttributeName : [UIColor whiteColor]}]; // 改变导航条内容的颜色
        [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithRed:(51)/255.f green:(171)/255.f blue:(160)/255.f alpha:1.f]]; // 改变导航条的系统默认颜色
        [[UINavigationBar appearance] setTranslucent:NO];// 设置导航条状态栏是否透明
    }
    
   HomePageViewController *vc = [[HomePageViewController alloc] init];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:vc];
    self.window.rootViewController = navigationController;
    
    [self setUIData];
    
    return YES;
}

- (void)setUIData{
    
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"titleArray"];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"imageArray"];
//    [[NSUserDefaults standardUserDefaults] synchronize];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"idArray"];
    
   NSUserDefaults *userD = [NSUserDefaults standardUserDefaults];
    
    
    // 先从本地获取首页界面的数据
    NSArray *titleArray = [userD objectForKey:@"titleArray"];
    NSArray *imageArray = [userD objectForKey:@"imageArray"];
    NSArray *idArray = [userD objectForKey:@"idArray"];
    
    // 从本地获取更多界面的数据
    NSArray *moretitleArray = [userD objectForKey:@"moretitleArray"];
    NSArray *moreimageArray = [userD objectForKey:@"moreimageArray"];
    NSArray *moreidArray = [userD objectForKey:@"moreidArray"];
    
    PTSingletonManager *manager = [PTSingletonManager shareInstance];
    
    /**
     *  程序第一次启动显示的数据
     */
    manager.showGridArray = [NSMutableArray arrayWithObjects:@"收银台",@"结算",@"分享", @"T+0", @"中心",@"D+1", @"商店",@"P2P", @"开通", @"充值", @"转账", @"扫码", @"记录" , @"快捷支付", @"明细", @"收款",@"更多", nil];
    manager.showImageGridArray = [NSMutableArray arrayWithObjects:
                                  @"more_icon_Transaction_flow",@"more_icon_cancle_deal", @"more_icon_Search",
                                  @"more_icon_t0",@"more_icon_shouyin" ,@"more_icon_d1",
                                  @"more_icon_Settlement",@"more_icon_Mall", @"more_icon_gift",
                                  @"more_icon_licai",@"more_icon_-transfer",@"more_icon_Recharge" ,
                                  @"more_icon_Transfer-" , @"more_icon_Credit-card-",@"more_icon_Manager",@"work-order",@"add_businesses", nil];
    manager.showGridIDArray = [NSMutableArray arrayWithObjects:
                               @"1000",@"1001", @"1002",
                               @"1003",@"1004",@"1005" ,@"1006",
                               @"1007",@"1008", @"1009",
                               @"1010",@"1011",@"1012" ,
                               @"1013" , @"1014",@"1015",@"0", nil];
    
    
    NSMutableString *defaString = [NSMutableString string];
    NSMutableString *localString = [NSMutableString string];
    
    [manager.showGridIDArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [defaString appendString:obj];
    }];
    [titleArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [localString appendString:obj];
    }];
    
    if (![defaString isEqualToString:localString] && localString.length > 0) {
        manager.showGridArray = [NSMutableArray arrayWithArray:titleArray];
        manager.showImageGridArray = [NSMutableArray arrayWithArray:imageArray];
        manager.showGridIDArray = [NSMutableArray arrayWithArray:idArray];
        
        manager.moreshowGridArray = [NSMutableArray arrayWithArray:moretitleArray];
        manager.moreshowImageGridArray = [NSMutableArray arrayWithArray:moreimageArray];
        manager.moreshowGridIDArray = [NSMutableArray arrayWithArray:moreidArray];
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
